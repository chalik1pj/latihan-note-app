const notes = [/**{
    id: string,
    title: string,
    createdAt: string,
    updatedAt: string,
    tags: Array of String,
    body: string,
}*/];

module.exports = notes;